
const JaTEmCtx = {
	
}

function generateJatemMap(code){
	var Map = {};
	function isSpace(code){
		return ([9, 10, 11, 32]).includes(code);
	}
	function isName(code){
		return (code>=48&&code<=57)||(code>=65&&code<=90)||(code>=97&&code<=122)||code==95;
	}
	var ctx = JaTEmCtx;
	//Código totalmente sub-dividido, por
	// caracteres especiais
	var words = [];
	{
		var longword = "";
		for(var i=0; i<code.length; i++){
			var car = code.charAt(i);
			if(!isName(code.charCodeAt(i))){
				if(longword!="")
					words.push(longword);
				words.push(car);
				longword = "";
			}else{
				longword += car;
			}
			if(i==code.length-1){
				if(longword!="")
					words.push(longword);
				break;
			}
		}
	}
	//Logo, o código deverá ser re-organizado, 
	// concatenando strings e limpando espaços em
	// branco.
	{
		var nwords = [];
		var string = "";
		var inString = null;
		var ammountBr = 0;
		for(var w=0; w<words.length; w++){
			var word = words[w];
			if(word=="\n"){
				if(w==0)
					continue;
				if(inString!=null){
					string+=word;
					continue;
				}
				if(ammountBr==0)
					nwords.push("\n");
				ammountBr++;
			}else{
				ammountBr = 0;
				if(inString!=null){
					if(word==inString){
						nwords.push(string);
						nwords.push(inString);
						inString = null
					}
					else
						string+=word;
				}else{
					string = "";
					if(word==" "||word=="\t")
						continue;
					if(word=='"'||word=="'"){
						inString = word;
						nwords.push(word);
					}else{
						nwords.push(word);
					}
				}
				//nwords.push(word);
			}
		}
		words = nwords;
	}
	//Então, comentários são removidos
	{
		var nwords = [];
		var comment = null;
		for(var i=0; i<words.length; i++){
			var act = words[i];
			var next = words[i+1];
			var combine = act+next;
			if(comment==null){
				if(combine=="//"||combine=="/*"){
					comment = combine;
				}else{
					nwords.push(act);
				}
			}else if(comment=="//"){
				if(act=="\n")
					comment = null
			}else if(comment=="/*"){
				if(combine=="*/"){
					comment = null;
					i++;
				}
			}
			//nwords.push(act);
		}
		words = nwords;
	}
	/*Código é passado por uma vistoria que
	// analisará cada componente, checará validez,
	// e gerará uma árvore de comandos*/
	{
		
	}
	Map.words = words;
	return Map;
}

//generateJatemMap()
