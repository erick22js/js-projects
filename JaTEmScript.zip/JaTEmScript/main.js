const editor = document.getElementById("editor");
const debug = document.getElementById("debug");



