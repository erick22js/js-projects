
function FepuExpression(){
	const unexpectedError = function(token, trace){
		throw new Error("Unexpected token "+token+"\ntrace: "+trace);
	}
	const expectedError = function(token, trace){
		throw new Error("Was expected an "+token+"\ntrace: "+trace);
	}
	const invalidOperation = function(t1, t2, sign){
		throw new Error("Cannot execute "+sign+" operation between type "+t1+" and "+t2);
	}
	const onlyAllowed = function(spec){
		throw new Error("Allowed only "+spec);
	}
	const nameT = /[0-9a-zA-Z_.]+/g;
	function splitAndCombine(txt){
		//split
		var mntks = txt.split(/([^0-9a-zA-Z_.])/g);
		//prompt("",JSON.stringify(mntks));
		var tokens = [];
		//combine
		var tk = "";
		var inString = null;
		combineL: for(var i=0; i<mntks.length; i++){
			var mnt = mntks[i];
			/*console.log(
				i+"=> "+mnt+"\n"+
				"inString: "+inString+"\n"+
				"tk: "+tk+"\n"+
				"tokens: "+tokens
			);*/
			var nmnt = mntks[i+1];
			if(inString!=null){
				tk+=mnt;
				if(mnt==inString){
					tokens.push(tk);
					inString = null;
					tk = "";
				}
				continue;
			}
			if(mnt==" "||mnt=="\t"||mnt=="\n"||mnt==""){
				continue combineL;
			}
			if(nmnt==""){
				mntks.splice(i+1, 1);
				i--;
				continue combineL;
			}
			switch(mnt){
				case "=":
				case ">":
				case "<":
				case "!":
					if(nmnt=="="){
						tokens.push(mnt+nmnt); i++;
						continue combineL;
					}else{
						tokens.push(mnt);
						continue combineL;
					}
					break;
				case '"':
				case "'":
					tk+=mnt;
					inString = tk;
					break;
				default:
					//console.log(mnt+" => "+nameT.exec(mnt));
					var valid = (mnt.match(nameT)==null)&&(signals[mnt]==null)&&(!(["(", ")", ","].includes(mnt)));
					//console.log(valid);
					if(valid)
						unexpectedError(mnt, valid);
					tokens.push(mnt);
			}
		}
		console.log(JSON.stringify(tokens));
		return tokens;
	}
	var signals = {
		"&":0,
		"|":0,
		"==":2,
		"!=":2,
		">=":2,
		"<=":2,
		">":2,
		"<":2,
		"+":4,
		"-":4,
		"*":6,
		"/":6,
	};
	var cmds = {
		"sqrt":{out:"number"},
		"min":{out:"number"},
		"max":{out:"number"},
		"random":{out:"number"},
	};
	var mainProperties = [
		"this.health", "target.health",
		//"this.health", "target.health",
	];
	var plusProperties = {
		
	};
	function createValue(id){
		//return id;
		if(id.type!=null)
			return id;
		//console.log(id+" => "+id.charAt(0));
		var mode = 
			id instanceof Array?
				"expression":
				(isNaN(id)&&!((id.charAt(0)==id.charAt(id.length-1))&&['"',"'"].includes(id.charAt(0)))?
					"variable": "constant");
		return {type:"value", "mode":mode, "identity":id};
	}
	function createOpr(id){
		//return id;
		return {type:"operator", "sign":id}
	}
	function createFunc(id){
		return {type:"function", "name":id, "args":[]};
	}
	function parseExpression(tokens){
		var i = 0;
		var openPs = [];
		function stepOrder(beginExp=null, beginOps=null){
			var values = [];
			if(beginExp!=null)
				values.push(beginExp);
			var ops = [];
			var negated = 0;
			if(beginOps!=null){
				if(beginOps=="!")
					negated = 1;
				ops.push(beginOps);
			}
			for(;true;){
				console.log("Before\n"+"values: "+JSON.stringify(values)+"\n"+
					"ops: "+JSON.stringify(ops));
				var tk = tokens[i];
				if(tk==null){
					var toks = [];
					toks.push(createValue(values[0]));
					if((ops.length)==1)
						toks.push(createOpr(ops[0]));
					if(values.length>1)
						toks.push(createValue(values[1]));
					if(openPs.length>0)
						expectedError(")");
					return toks;
				}
				if(tk=="!"){
					i++;
					values.push(stepOrder(null, "!"));
					continue;
				}
				if(ops[0]=="!"&&values.length>0){
					var toks = [];
					toks.push(createValue(values[0]));
					toks.push(createOpr(ops[0]));
					return toks;
				}
				if(tk=="("){
					if((values.length!=(ops.length-negated)))
						unexpectedError(tk);
					i++;
					openPs.push("exp");
					var v = stepOrder();
					values.push(v);
					continue;
				}
				if(tk==")"){
					//console.log(JSON.stringify(values)+""+JSON.stringify(ops));
					if(values.length==(ops.length-negated))
						unexpectedError(tk, JSON.stringify(values)+""+JSON.stringify(ops));
					if(openPs[openPs.length-1]!="func")
						i++;
					openPs.pop();
					var toks = [];
					toks.push(createValue(values[0]));
					if((ops.length)==1)
						toks.push(createOpr(ops[0]));
					if(values.length>1)
						toks.push(createValue(values[1]));
					return toks;
				}
				if(tk==","){
					if(values.length==(ops.length-negated))
						unexpectedError(tk);
					i++;
					var toks = [];
					toks.push(createValue(values[0]));
					if((ops.length)==1)
						toks.push(createOpr(ops[0]));
					if(values.length>1)
						toks.push(createValue(values[1]));
					return toks;
				}
				if(signals[tk]!=null){ //Is a signal
					if(tk=="+"||tk=="-"){
						if(values.length<ops.length)
							unexpectedError(tk);
						if(values.length==0){
							values.push(createValue(0));
						}
						ops.push(tk);
					}else{
						if(values.length<=ops.length)
							unexpectedError(tk);
						ops.push(tk);
					}
					if((ops.length)>1){
						if(signals[ops[1]]>signals[ops[0]]){
							ops.pop();
							values.pop();
							i--;
							values.push(stepOrder());
							continue;
						}else{
							var toks = [];
							toks.push(createValue(values[0]));
							toks.push(createOpr(ops[0]));
							toks.push(createValue(values[1]));
							return stepOrder(toks);
						}
					}
				}else if(cmds[tk]!=null){ //Is a function
					var func = createFunc(tk); i++;
					if(tokens[i]!="(")
						expectedError("(");
					openPs.push("func");
					i++;
					while(tokens[i]!=")"&&openPs[openPs.length-1]=="func"){
						func.args.push(createValue(stepOrder()));
						if(tokens[i]==null){
							unexpectedError("end of expression");
						}
					}
					values.push(func);
					i++;
					continue;
				}
				else{ //Is a value (constant or variable)
					if(ops.length<values.length)
						unexpectedError(tk, "After\n"+"values: "+JSON.stringify(values)+"\n"+
							"ops: "+JSON.stringify(ops));
					values.push(tk);
				}
				console.log("After\n"+"values: "+JSON.stringify(values)+"\n"+
					"ops: "+JSON.stringify(ops));
				i++;
			}
		}
		var ordered = createValue(stepOrder());
		return ordered;
	}
	function getValuesClass(t1, t2){
		var mtypes = "";
		if(t1=="string"||t2=="string")
			mtypes += "_string";
		if(t1=="number"||t2=="number")
			mtypes += "_number";
		if(t1=="boolean"||t2=="boolean")
			mtypes += "_boolean";
		return mtypes;
	}
	function validateExpression(expr, father){
		if(expr.type=="value"){
			if(expr.mode=="constant"){
				var value = expr.identity;
				if((value.charAt(0)==value.charAt(value.length-1))&&['"',"'"].includes(value.charAt(0))){
					expr.class = "string";
				}else{
					expr.class = "number";
				}
			}else if(expr.mode=="variable"){
				
			}else if(expr.mode=="expression"){
				for(var i=0; i<expr.identity.length; i++){
					validateExpression(expr.identity[i], expr);
				}
				if(expr.identity.length<=2){
					expr.class = expr.identity[0].class;
				}else{
					var t1 = expr.identity[0].class;
					var t2 = expr.identity[2].class
					var sign = expr.identity[1].sign;
					var mtypes = getValuesClass(t1, t2);
					if(expr.evalMode=="comparation"){
						if((t1=="string"||t2=="string")&&!(["!=","=="].includes(sign)))
							invalidOperation(t1, t2, sign)
						if(t1!=t2)
							invalidOperation(t1, t2, "comparation");
						else{
							expr.class = "boolean";
						}
					}
					else if(expr.evalMode=="arithmetic"){
						if(t1=="string"||t2=="string"){
							if(sign!="+")
								invalidOperation(t1, t2, sign);
							expr.class = "string";
						}else
							expr.class = "number";
					}
					else if(expr.evalMode=="condition"){
						if(t1!="boolean"||t2!="boolean")
							onlyAllowed("to use boolean values in conditions");
						expr.class = "boolean";
					}
				}
			}
		}else if(expr.type=="operator"){
			if(["+","-","*","/"].includes(expr.sign)){
				father.evalMode = "arithmetic";
			}
			else if(["==","!=",">=","<=", ">", "<"].includes(expr.sign)){
				father.evalMode = "comparation";
			}
			else if(["|","&"].includes(expr.sign)){
				father.evalMode = "condition";
			}
			else if(["!"].includes(expr.sign)){
				father.evalMode = "negate";
			}
		}else if(expr.type=="function"){
			for(var i=0; i<expr.args.length; i++){
				validateExpression(expr.args[i], expr);
			}
			expr.class = cmds[expr.name].out;
		}else{
			throw new Error("unknow type");
			//unexpectedError()
		}
	}
	this.readAndValidate = function(str){
		var tokens = splitAndCombine(str);
		debug.textContent = JSON.stringify(tokens);
		var expr = parseExpression(tokens);
		var result = {}
		validateExpression(expr, result);
		debug.textContent = JSON.stringify(expr, null, 2);
	}
}

var expr = new FepuExpression();
expr.readAndValidate(
'(5>8&3<7)+1'
//'(5>7&(4==5))+o*!sqrt(sqrt(5*2, 10+8, sqrt(8)))'
//`35+2<3&78>4*2`
//`25+73*8+1-56/4+1`
);
